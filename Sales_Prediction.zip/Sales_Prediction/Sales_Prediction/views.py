import tkinter as tk
from django.shortcuts import render
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import os


def index(request):
    return render(request, 'index.html')

def prediction(request):
    return render(request, 'prediction.html')

def service(request):
    return render(request, 'service.html')

def team(request):
    return render(request, 'team.html')

def about(request):
    return render(request, 'about.html')

def login(request):
    return render(request, 'login.html')

def readmore(request):
    return render(request, 'readmore.html')

def register(request):
    return render(request, 'register.html')

def viewpage(request):
    
    # Load and preprocess the dataset
    data = pd.read_csv('E:/Study_Data/8th semester/final yearproject/Project/Sales_Prediction - Copy/dataset.csv')
    data = data.drop(columns=['Date', 'year', 'day', 'month', 'weekly_sales'])
    data = data[['Store', 'Product', 'week_of_year', 'Base Price', 'promotion', 'Price', 'Is_Holiday', 'Weekly_Units_Sold']]
    
    # Encode categorical variables
    X = data.drop(columns=['Weekly_Units_Sold'], axis=1)
    X_encoded = pd.get_dummies(X, columns=['promotion', 'Is_Holiday'])
    Y = data['Weekly_Units_Sold']

    # Split the data into training and testing sets
    X_train, X_test, Y_train, Y_test = train_test_split(X_encoded, Y, test_size=0.2, random_state=0)

    # Train the linear regression model
    model = LinearRegression()
    model.fit(X_train, Y_train)

    # Debug: Print all GET parameters
    print("GET parameters:", request.GET)

    # Retrieve and convert input values from the GET request
    Store_var = float(request.GET['store'])
    Product_var = float(request.GET['product'])
    week_of_year_var = float(request.GET['week_year'])
    Base_price_var = float(request.GET['base_price'])
    Price_var = float(request.GET['price'])
    Promotion_var = request.GET['promotion']
    Is_holiday_var = request.GET['is_holiday']

    # Encode the input values for categorical variables
    # Get the dummy columns names created during training
    columns_encoded = list(X_encoded.columns)
    
    # Initialize the input list with zeros for all columns
    input_list = [0] * len(columns_encoded)
    
    # Set the values for the numerical columns
    input_list[columns_encoded.index('Store')] = Store_var
    input_list[columns_encoded.index('Product')] = Product_var
    input_list[columns_encoded.index('week_of_year')] = week_of_year_var
    input_list[columns_encoded.index('Base Price')] = Base_price_var
    input_list[columns_encoded.index('Price')] = Price_var
    
    # Set the values for the encoded categorical columns
    promotion_col = f'promotion_{Promotion_var}'
    is_holiday_col = f'Is_Holiday_{Is_holiday_var}'
    
    if promotion_col in columns_encoded:
        input_list[columns_encoded.index(promotion_col)] = 1
    if is_holiday_col in columns_encoded:
        input_list[columns_encoded.index(is_holiday_col)] = 1

    # Ensure all values are numeric
    input_list = [float(value) for value in input_list]

    # Print the input list and its length for debugging
    print("Input List:", input_list)
    print("Input List Length:", len(input_list))

    # Print the columns of the training data for debugging
    print("Training Data Columns:", X_encoded.columns)
    print("Training Data Columns Length:", len(X_encoded.columns))

    # Make a prediction
    Y_pred = model.predict([input_list])
    
    # Create a graph showing input values and the predicted output
    fig, ax = plt.subplots()
    labels = ['Store', 'Product', 'Week of Year', 'Base Price', 'Price', 'Promotion', 'Is Holiday', 'Predicted Units Sold']
    values = [Store_var, Product_var, week_of_year_var, Base_price_var, Price_var, float(Promotion_var), float(Is_holiday_var), Y_pred[0]]
    
    ax.barh(labels, values, color='blue')
    ax.set_xlabel('Values')
    ax.set_title('Input Values and Predicted Output')

    # Save the graph to a file
    graph_path = 'static/graph.png'
    plt.savefig(graph_path)
    plt.close()

    data = {
        'result': Y_pred[0],
        'graph_path': graph_path,
        'store': Store_var,
        'product': Product_var,
        'week_year': week_of_year_var,
        'base_price': Base_price_var,
        'price': Price_var,
        'promotion': Promotion_var,
        'is_holiday': Is_holiday_var,
    }
    return render(request, 'viewpage.html', data)
